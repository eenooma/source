/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_terms`; */
/* PRE_TABLE_NAME: `1706446063_wp_terms`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1706446063_wp_terms` ( `term_id` bigint unsigned NOT NULL AUTO_INCREMENT, `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '', `slug` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '', `term_group` bigint NOT NULL DEFAULT '0', PRIMARY KEY (`term_id`), KEY `slug` (`slug`(191)), KEY `name` (`name`(191))) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1706446063_wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES (1,'미분류','%eb%af%b8-%eb%b6%84%eb%a5%98',0),(2,'twentytwentythree','twentytwentythree',0),(3,'twentytwentyfour','twentytwentyfour',0),(5,'주메뉴','%ec%a3%bc%eb%a9%94%eb%89%b4',0),(6,'footer','footer',0),(7,'twentytwentytwo','twentytwentytwo',0);
