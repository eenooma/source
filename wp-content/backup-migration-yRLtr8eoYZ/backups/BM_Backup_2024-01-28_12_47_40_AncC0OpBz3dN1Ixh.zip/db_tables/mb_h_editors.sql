/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `mb_h_editors`; */
/* PRE_TABLE_NAME: `1706446063_mb_h_editors`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1706446063_mb_h_editors` ( `pid` int unsigned NOT NULL AUTO_INCREMENT, `user_pid` int unsigned NOT NULL DEFAULT '0', `user_name` varchar(100) NOT NULL DEFAULT '', `image_path` varchar(255) NOT NULL DEFAULT '', `content` mediumtext NOT NULL, `color` text NOT NULL, `width` text NOT NULL, `point_x` text NOT NULL, `point_y` text NOT NULL, `alpha` text NOT NULL, `ip` varchar(40) NOT NULL DEFAULT '', `agent` varchar(30) NOT NULL DEFAULT '', `reg_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00', PRIMARY KEY (`pid`), KEY `reg_date` (`reg_date`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='h-editor table';
