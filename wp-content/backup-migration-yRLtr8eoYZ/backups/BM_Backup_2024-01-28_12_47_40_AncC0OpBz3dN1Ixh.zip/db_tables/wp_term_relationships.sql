/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_term_relationships`; */
/* PRE_TABLE_NAME: `1706446063_wp_term_relationships`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1706446063_wp_term_relationships` ( `object_id` bigint unsigned NOT NULL DEFAULT '0', `term_taxonomy_id` bigint unsigned NOT NULL DEFAULT '0', `term_order` int NOT NULL DEFAULT '0', PRIMARY KEY (`object_id`,`term_taxonomy_id`), KEY `term_taxonomy_id` (`term_taxonomy_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1706446063_wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES (1,1,0),(7,2,0),(8,3,0),(57,5,0),(58,5,0),(59,5,0),(60,5,0),(61,5,0),(62,5,0),(63,5,0),(64,5,0),(65,5,0),(66,5,0),(67,5,0),(68,5,0),(69,5,0),(70,5,0),(79,5,0),(80,5,0),(81,5,0),(82,5,0),(83,5,0),(88,3,0),(88,6,0),(89,7,0);
