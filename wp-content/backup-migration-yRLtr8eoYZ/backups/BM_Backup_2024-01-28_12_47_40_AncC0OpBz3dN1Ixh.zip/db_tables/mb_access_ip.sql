/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `mb_access_ip`; */
/* PRE_TABLE_NAME: `1706446063_mb_access_ip`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1706446063_mb_access_ip` ( `pid` int unsigned NOT NULL AUTO_INCREMENT, `type` tinyint NOT NULL DEFAULT '0', `ip` varchar(40) NOT NULL DEFAULT '', `description` varchar(255) NOT NULL DEFAULT '', `reg_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00', PRIMARY KEY (`pid`), KEY `type` (`type`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
