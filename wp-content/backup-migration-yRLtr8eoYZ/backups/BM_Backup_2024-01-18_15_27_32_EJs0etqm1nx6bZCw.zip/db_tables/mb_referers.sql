/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `mb_referers`; */
/* PRE_TABLE_NAME: `1705591652_mb_referers`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1705591652_mb_referers` ( `pid` int(10) unsigned NOT NULL AUTO_INCREMENT, `date` char(10) NOT NULL DEFAULT '', `referer_host` varchar(255) NOT NULL DEFAULT '', `referer_url` varchar(255) NOT NULL DEFAULT '', `referer_query` varchar(255) NOT NULL DEFAULT '', `reg_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00', `ip` varchar(40) NOT NULL DEFAULT '', `agent` varchar(30) NOT NULL DEFAULT '', PRIMARY KEY (`pid`), KEY `date` (`date`), KEY `reg_date` (`reg_date`), KEY `referer_host` (`referer_host`), KEY `referer_query` (`referer_query`), KEY `referer_url` (`referer_url`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
