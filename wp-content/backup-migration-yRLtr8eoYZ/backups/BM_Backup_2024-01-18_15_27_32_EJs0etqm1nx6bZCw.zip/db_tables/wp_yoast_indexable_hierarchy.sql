/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_yoast_indexable_hierarchy`; */
/* PRE_TABLE_NAME: `1705591652_wp_yoast_indexable_hierarchy`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1705591652_wp_yoast_indexable_hierarchy` ( `indexable_id` int(11) unsigned NOT NULL, `ancestor_id` int(11) unsigned NOT NULL, `depth` int(11) unsigned DEFAULT NULL, `blog_id` bigint(20) NOT NULL DEFAULT 1, PRIMARY KEY (`indexable_id`,`ancestor_id`), KEY `indexable_id` (`indexable_id`), KEY `ancestor_id` (`ancestor_id`), KEY `depth` (`depth`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1705591652_wp_yoast_indexable_hierarchy` (`indexable_id`, `ancestor_id`, `depth`, `blog_id`) VALUES (1,0,0,1),(4,0,0,1),(5,0,0,1),(6,0,0,1),(7,0,0,1),(8,0,0,1),(9,0,0,1),(10,0,0,1),(11,0,0,1),(12,0,0,1),(13,0,0,1),(14,0,0,1),(15,0,0,1),(16,0,0,1),(17,0,0,1),(18,0,0,1),(19,0,0,1),(20,0,0,1),(21,0,0,1),(22,0,0,1),(23,0,0,1);
