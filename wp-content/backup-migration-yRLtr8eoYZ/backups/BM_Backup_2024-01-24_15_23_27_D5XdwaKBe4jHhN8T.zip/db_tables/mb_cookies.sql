/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `mb_cookies`; */
/* PRE_TABLE_NAME: `1706109808_mb_cookies`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1706109808_mb_cookies` ( `pid` int(10) unsigned NOT NULL AUTO_INCREMENT, `user_pid` int(10) unsigned NOT NULL DEFAULT 0, `user_name` varchar(100) NOT NULL DEFAULT '', `board_name` varchar(50) NOT NULL DEFAULT '', `cookie_type` varchar(255) NOT NULL DEFAULT '', `cookie_name` varchar(255) NOT NULL DEFAULT '', `cookie_value` varchar(255) NOT NULL DEFAULT '', `reg_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00', `ip` varchar(40) NOT NULL DEFAULT '', `agent` varchar(30) NOT NULL DEFAULT '', PRIMARY KEY (`pid`), KEY `board_name` (`board_name`), KEY `user_pid` (`user_pid`,`board_name`), KEY `cookie_type` (`cookie_type`), KEY `reg_date` (`reg_date`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
