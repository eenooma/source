/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `mb_logs`; */
/* PRE_TABLE_NAME: `1705412163_mb_logs`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1705412163_mb_logs` ( `pid` int(10) unsigned NOT NULL AUTO_INCREMENT, `user_pid` int(10) unsigned NOT NULL DEFAULT 0, `user_name` varchar(100) NOT NULL DEFAULT '', `board_name` varchar(50) NOT NULL DEFAULT '', `mode` varchar(255) NOT NULL DEFAULT '', `action` varchar(255) NOT NULL DEFAULT '', `type` varchar(255) NOT NULL DEFAULT '', `content` text NOT NULL, `reg_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00', `ip` varchar(40) NOT NULL DEFAULT '', `agent` varchar(30) NOT NULL DEFAULT '', PRIMARY KEY (`pid`), KEY `board_name` (`board_name`), KEY `user_pid` (`user_pid`), KEY `user_name` (`user_name`), KEY `reg_date` (`reg_date`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
INSERT INTO `1705412163_mb_logs` (`pid`, `user_pid`, `user_name`, `board_name`, `mode`, `action`, `type`, `content`, `reg_date`, `ip`, `agent`) VALUES (1,1,'admin','users','user','join','join','join','2023-11-30 17:32:49','172.18.0.1','d_Chrome');
